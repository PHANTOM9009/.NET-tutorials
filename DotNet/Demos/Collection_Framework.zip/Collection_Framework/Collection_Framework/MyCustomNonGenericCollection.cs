﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collection_Framework
{
    internal class MyCustomNonGenericCollection:IEnumerable
    {
        object[] objItems = new object[4];
        int ctr;
        public MyCustomNonGenericCollection() 
        {

        }
        public void AddItem(object item)
        {
            objItems[ctr++] = item;
        }

        public IEnumerator GetEnumerator()
        {
            return objItems.GetEnumerator();
        }
    }
}
