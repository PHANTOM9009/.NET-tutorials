﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collection_Framework
{
    internal class MyGenericCollection<T>
    {
        T[] items = new T[4];
        int ctr = 0;
        public int Count 
        {
            get { return ctr; }
        }

        public void AddItem(T item)
        {
            items[ctr++] = item;
        }

        public T[] GetItems()
        {
            return items;
        }

    }
}
