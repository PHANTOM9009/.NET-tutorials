﻿using System.Collections;
using System.Collections.Generic;

namespace Collection_Framework
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Non-Generic Collections-----
            //ArrayList_Demo();
            //Stack_Demo();
            //Queue_Demo();
            //Hashtable_Demo();
            NonGeneric_CustomCollection_Demo();
            //Generic Collections-----
            //Generic_List_Demo();
            //Generic_Stack_Demo();
            //Generic_Queue_Demo();
            //Generic_Dictionary_Demo();
            //Generic_CustomCollection_Demo();
            //
            Console.ReadLine();
        }
        static void ArrayList_Demo()
        {
            Console.WriteLine("----- Non-Generic Classes: Array List -----");
            //
            ArrayList objALCountries = new ArrayList();
            objALCountries.Add("America");
            objALCountries.Add("Australia");
            objALCountries.Add("UK");
            objALCountries.Add("India");
            objALCountries.Add("Russia");
            //
            Console.WriteLine("Capacity: " + objALCountries.Capacity);
            Console.WriteLine("Count: " + objALCountries.Count);
            Console.WriteLine("Contains Country 'Russia': " 
                + objALCountries.Contains("Russia"));
            object[] objCountries = new object[objALCountries.Count];
            objALCountries.CopyTo(objCountries);
            //
            Console.WriteLine("----- List of Countries from a new Array -----");
            for (int i = 0; i < objCountries.Length; i++)
            {
                Console.WriteLine(objCountries[i]);
            }
            //
            Console.WriteLine("----- List of Countries using For Loop -----");
            for (int i = 0; i < objALCountries.Count; i++)
            {
                Console.WriteLine(objALCountries[i]);
            }
            objALCountries.Insert(1,"China");
            //objALCountries.RemoveAt(2);
            objALCountries.Remove("Australia");
            Console.WriteLine("IndexOf the item: China: " 
                + objALCountries.IndexOf("China"));
            objALCountries.Reverse();
            Console.WriteLine("----- List of Countries using For Each Loop -----");
            foreach (var objALCountry in objALCountries)
            {
                Console.WriteLine(objALCountry);
            }
        }
        static void Stack_Demo()
        {
            Console.WriteLine("---- Non Generic: Stack Class ----");
            Stack objStackMonths = new Stack();
            objStackMonths.Push("Jan");
            objStackMonths.Push("Feb");
            objStackMonths.Push("Mar");
            objStackMonths.Push("Apr");
            Console.WriteLine("---- List of Months using ForEach Loop ----");
            foreach(var objStackMonth in objStackMonths)
            {
                Console.WriteLine(objStackMonth);
            }
            //Console.WriteLine("Item Popped: " + objStackMonths.Pop());
            //Console.WriteLine("---- List of Months after calling Pop() method ----");
            Console.WriteLine("Item Peeked: " + objStackMonths.Peek());
            Console.WriteLine("---- List of Months after calling Peek() method ----");

            foreach (var objStackMonth in objStackMonths)
            {
                Console.WriteLine(objStackMonth);
            }
        }
        static void Queue_Demo()
        {
            Console.WriteLine("---- Non Generic: Queue Class ----");
            Queue objQueueMonths = new Queue();
            objQueueMonths.Enqueue("Jan");
            objQueueMonths.Enqueue("Feb");
            objQueueMonths.Enqueue("Mar");
            objQueueMonths.Enqueue("Apr");
            Console.WriteLine("---- List of Months using ForEach Loop ----");
            foreach (var objQueueMonth in objQueueMonths)
            {
                Console.WriteLine(objQueueMonth);
            }
            //Console.WriteLine("Item Dequeued: " + objQueueMonths.Dequeue());
            //Console.WriteLine("---- List of Months after calling Dequeue() method ----");
            Console.WriteLine("Item Peeked: " + objQueueMonths.Peek());
            Console.WriteLine("---- List of Months after calling Peek() method ----");

            foreach (var objQueueMonth in objQueueMonths)
            {
                Console.WriteLine(objQueueMonth);
            }
        }
        static void Hashtable_Demo()
        {
            Console.WriteLine("---- Non Generic: Hashtable -----");
            Hashtable objHT = new Hashtable();
            objHT.Add(1, "Satyajeet");//objDE1(1,"Satyajeet")
            objHT.Add(2, "Simran");//objDE2(2,"Simran")
            objHT.Add(3, "Joanne");//objDE3(3,"Joanne")
            objHT.Add(4, "Ealishaw");//objDE4(4,"Ealishaw")
            //
            Console.WriteLine("---- List of Employee Names using ForEach Loop -----");
            foreach (DictionaryEntry objDE in objHT)
            {
                Console.WriteLine("Key: {0} and Value: {1}", objDE.Key, objDE.Value);
            }
            Console.WriteLine("---- List of Employee Names using While Loop -----");
            IDictionaryEnumerator objIDE = objHT.GetEnumerator();
            while (objIDE.MoveNext())
            {
                Console.WriteLine("Key: {0} and Value: {1}",
                    objIDE.Key, objIDE.Value);
            }
        }

        static void NonGeneric_CustomCollection_Demo()
        {
            Console.WriteLine("----- Custom Non-Generic Collection Class -----");
            //
            MyCustomNonGenericCollection objMCNGC = new MyCustomNonGenericCollection();
            objMCNGC.AddItem("America");
            objMCNGC.AddItem("Australia");
            objMCNGC.AddItem("UK");
            objMCNGC.AddItem("India");
            //
            /*
            Console.WriteLine("----- List of Countries from a CustomGenericCollection -----");
            string[] strCountries = objMCNGC.GetItems();
            //
            for (int i = 0; i < strCountries.Length; i++)
            {
                Console.WriteLine(strCountries[i]);
            }
            */
            Console.WriteLine("---- List of items from CustomNonGenericCollection using ForEach Loop -----");
            foreach (var item in objMCNGC)
            {
                Console.WriteLine(item);
            }
        }

        static void Generic_List_Demo()
        {
            Console.WriteLine("----- Generic Classes: List -----");
            //
            List<string> objListCountries = new List<string>();
            objListCountries.Add("America");
            objListCountries.Add("Australia");
            objListCountries.Add("UK");
            objListCountries.Add("India");
            objListCountries.Add("Russia");
            //
            Console.WriteLine("Capacity: " + objListCountries.Capacity);
            Console.WriteLine("Count: " + objListCountries.Count);
            Console.WriteLine("Contains Country 'Russia': "
                + objListCountries.Contains("Russia"));
            string[] objCountries = new string[objListCountries.Count];
            objListCountries.CopyTo(objCountries);
            //
            Console.WriteLine("----- List of Countries from a new Array -----");
            for (int i = 0; i < objCountries.Length; i++)
            {
                Console.WriteLine(objCountries[i]);
            }
            //
            Console.WriteLine("----- List of Countries using For Loop -----");
            for (int i = 0; i < objListCountries.Count; i++)
            {
                Console.WriteLine(objListCountries[i]);
            }
            objListCountries.Insert(1, "China");
            //objALCountries.RemoveAt(2);
            objListCountries.Remove("Australia");
            Console.WriteLine("IndexOf the item: China: "
                + objListCountries.IndexOf("China"));
            objListCountries.Reverse();
            Console.WriteLine("----- List of Countries using For Each Loop -----");
            foreach (var objListCountry in objListCountries)
            {
                Console.WriteLine(objListCountry);
            }
        }
        static void Generic_Stack_Demo()
        {
            Console.WriteLine("---- Generic: Stack Class ----");
            Stack<string> objStackMonths = new Stack<string>();
            objStackMonths.Push("Jan");
            objStackMonths.Push("Feb");
            objStackMonths.Push("Mar");
            objStackMonths.Push("Apr");
            Console.WriteLine("---- List of Months using ForEach Loop ----");
            foreach (var objStackMonth in objStackMonths)
            {
                Console.WriteLine(objStackMonth);
            }
            //Console.WriteLine("Item Popped: " + objStackMonths.Pop());
            //Console.WriteLine("---- List of Months after calling Pop() method ----");
            Console.WriteLine("Item Peeked: " + objStackMonths.Peek());
            Console.WriteLine("---- List of Months after calling Peek() method ----");

            foreach (var objStackMonth in objStackMonths)
            {
                Console.WriteLine(objStackMonth);
            }
        }
        static void Generic_Queue_Demo()
        {
            Console.WriteLine("---- Generic: Queue Class ----");
            Queue<string> objQueueMonths = new Queue<string>();
            objQueueMonths.Enqueue("Jan");
            objQueueMonths.Enqueue("Feb");
            objQueueMonths.Enqueue("Mar");
            objQueueMonths.Enqueue("Apr");
            Console.WriteLine("---- List of Months using ForEach Loop ----");
            foreach (var objQueueMonth in objQueueMonths)
            {
                Console.WriteLine(objQueueMonth);
            }
            //Console.WriteLine("Item Dequeued: " + objQueueMonths.Dequeue());
            //Console.WriteLine("---- List of Months after calling Dequeue() method ----");
            Console.WriteLine("Item Peeked: " + objQueueMonths.Peek());
            Console.WriteLine("---- List of Months after calling Peek() method ----");

            foreach (var objQueueMonth in objQueueMonths)
            {
                Console.WriteLine(objQueueMonth);
            }
        }
        static void Generic_Dictionary_Demo()
        {
            Console.WriteLine("---- Generic: Dictionary -----");
            Dictionary<int,string> objDictionary = new Dictionary<int, string>();
            objDictionary.Add(1, "Satyajeet");//objKVP1(1,"Satyajeet")
            objDictionary.Add(2, "Simran");//objKVP2(2,"Simran")
            objDictionary.Add(3, "Joanne");//objKVP3(3,"Joanne")
            objDictionary.Add(4, "Ealishaw");//objKVP4(4,"Ealishaw")
            //
            Console.WriteLine("---- List of Employee Names using ForEach Loop -----");
            foreach (KeyValuePair<int,string> objKVP in objDictionary)
            {
                Console.WriteLine("Key: {0} and Value: {1}", objKVP.Key, objKVP.Value);
            }
            Console.WriteLine("---- List of Employee Names using While Loop -----");
            IDictionaryEnumerator objIDE = objDictionary.GetEnumerator();
            while (objIDE.MoveNext())
            {
                Console.WriteLine("Key: {0} and Value: {1}",
                    objIDE.Key, objIDE.Value);
            }
        }
        static void Generic_CustomCollection_Demo()
        {
            Console.WriteLine("----- Custom Generic Collection Classes: -----");
            //
            MyGenericCollection<string> objMGC = new MyGenericCollection<string>();
            objMGC.AddItem("America");
            objMGC.AddItem("Australia");
            objMGC.AddItem("UK");
            objMGC.AddItem("India");
            //
            Console.WriteLine("----- List of Countries from a CustomGenericCollection -----");
            string[] strCountries = objMGC.GetItems();
            //
            for (int i = 0; i < strCountries.Length; i++)
            {
                Console.WriteLine(strCountries[i]);
            }
            //foreach (var item in objMGC)
            //{

            //}
        }
    }
}
