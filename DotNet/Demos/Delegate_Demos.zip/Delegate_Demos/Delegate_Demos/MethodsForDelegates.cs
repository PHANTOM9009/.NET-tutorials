﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate_Demos
{
    internal class MethodsForDelegates
    {
        internal void Method_One()
        {
            Console.WriteLine("---- Method One ----");
            for (int i = 0; i < 100; i++)
            {
                Console.WriteLine("Method One Counter Value: {0}", i);
            }
        }
        internal void Method_Two()
        {
            Console.WriteLine("---- Method Two ----");
            for (int i = 0; i < 100; i++)
            {
                Console.WriteLine("Method Two Counter Value: {0}", i);
            }
        }
    }
}
