﻿namespace Delegate_Demos
{
    internal class Program
    {
        delegate void DelegateTest();
        delegate int ArithmeticDelegate(int num1, int num2);
        delegate void AsyncDelegate();
        delegate void AnonDelegate(string message);
        static void Main(string[] args)
        {
            //Delegates_Without_Params();
            //Delegates_With_Params();
            //AsynchronousDelegate();
            AnonymousDelegate();
            //
            Console.Read();
        }

        static void Delegates_Without_Params()
        {
            //Standard way of calling a function:---------------
            /*
            TestDelegates objTestDelegate = new TestDelegates();
            objTestDelegate.Method_One();
            */
            Console.WriteLine("--- UniCast Delegate Example 1 ---");
            MethodsForDelegates objTestDelegate = new MethodsForDelegates();
            //UniCast Delegate: Example 1: ---------------
            DelegateTest objDelTest1 = new DelegateTest(objTestDelegate.Method_One);
            //objDelTest1.Invoke();
            objDelTest1();
            //
            Console.WriteLine("--- UniCast Delegate Example 2 ---");
            //UniCast Delegate: Example 2: ---------------
            DelegateTest objDelTest2 = new DelegateTest(objTestDelegate.Method_Two);
            //objDelTest2.Invoke();
            objDelTest2();
            //
            Console.WriteLine("--- MultiCast Delegate Example 1 ---");
            //MultiCast Delegate: Example 1: ---------------
            DelegateTest objMultiCastDelTest;
            objMultiCastDelTest = objDelTest1;
            objMultiCastDelTest += objDelTest2;
            objMultiCastDelTest();
        }

        static void Delegates_With_Params()
        {
            Console.WriteLine("--- UniCast Delegate with Params-RetVal: Example 1 ---");
            //
            Console.WriteLine("--- UniCast Delegate Example 1 ---");
            Calculator objCalculator = new Calculator();
            //
            ArithmeticDelegate objArithmeticDelegate1 
                = new ArithmeticDelegate(objCalculator.Addition);
            int additionResult = objArithmeticDelegate1(100, 20);
            Console.WriteLine("Addition is: " + additionResult);
            //
            Console.WriteLine("--- UniCast Delegate Example 2 ---");
            ArithmeticDelegate objArithmeticDelegate2 
                = new ArithmeticDelegate(objCalculator.Subtraction);
            int subtractionResult = objArithmeticDelegate2(100, 20);
            Console.WriteLine("Subtraction is: " + subtractionResult);
            //
            Console.WriteLine("--- MultiCast Delegate with Params-RetVal: Example 1 ---");
            ArithmeticDelegate objMultiCastArithmeticDel;
            objMultiCastArithmeticDel = objArithmeticDelegate1;
            objMultiCastArithmeticDel += objArithmeticDelegate2;
            int resultFromMultiCastDel = objMultiCastArithmeticDel(100, 20);
            Console.WriteLine("Output from MultiCast Delegate:" + resultFromMultiCastDel);
            //
            Console.WriteLine("--- MultiCast Delegate InvocationList: Example 2 ---");
            Delegate[] objDelInvocationList = objMultiCastArithmeticDel.GetInvocationList();
            foreach (Delegate objDelInvocationObject in objDelInvocationList)
            {
                ArithmeticDelegate objArithmeticDel = objDelInvocationObject as ArithmeticDelegate;
                int result = objArithmeticDel(100, 20);
                Console.WriteLine("Outupt from a Delegate: " + result);
            }
        }

        static void AsynchronousDelegate()
        {
            Console.WriteLine("--- UniCast Delegate Example 1 ---");
            MethodsForDelegates objTestDelegate = new MethodsForDelegates();
            //UniCast Delegate: Example 1: ---------------
            AsyncDelegate objAsyncDel = new AsyncDelegate(objTestDelegate.Method_One);
            //IAsyncResult objIAR =  objAsyncDel.BeginInvoke(null, null);
            Task task = Task.Run(() => objAsyncDel());
            objTestDelegate.Method_Two();
            //task.Wait();
            task.ContinueWith(t => Console.WriteLine("End of the task...."));
            //
            //Foreground Task:-----
            /*
            Console.WriteLine("--- UniCast Delegate Example 2 ---");
            //UniCast Delegate: Example 2: ---------------
            DelegateTest objDelTest2 = new DelegateTest(objTestDelegate.Method_Two);
            objDelTest2.Invoke();
            */
            //objTestDelegate.Method_Two();
            //
            //objAsyncDel.EndInvoke(objIAR);

        }

        static void AnonymousDelegate()
        {
            AnonDelegate objAnonDel = delegate (string message)
            {
                Console.WriteLine(message);
            };
            objAnonDel("Hello World!");
        }

        /*
        static void AsynchronousDelegate()
        {
            Console.WriteLine("--- UniCast Delegate Example 1 ---");
            MethodsForDelegates objTestDelegate = new MethodsForDelegates();
            //UniCast Delegate: Example 1: ---------------
            AsyncDelegate objAsyncDel = new AsyncDelegate(objTestDelegate.Method_One);
            IAsyncResult objIAR =  objAsyncDel.BeginInvoke(null, null);
            //
            //Foreground Task:-----
            //Option 1
            Console.WriteLine("--- UniCast Delegate Example 2 ---");
            //UniCast Delegate: Example 2: ---------------
            DelegateTest objDelTest2 = new DelegateTest(objTestDelegate.Method_Two);
            objDelTest2.Invoke();
            //Option 2
            //objTestDelegate.Method_Two();
            //
            objAsyncDel.EndInvoke(objIAR);

        }
        */
    }
}
