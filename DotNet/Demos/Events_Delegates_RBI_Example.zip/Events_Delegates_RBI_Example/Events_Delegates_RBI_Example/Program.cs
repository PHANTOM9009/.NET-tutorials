﻿namespace Events_Delegates_RBI_Example
{
    internal class AxisBank
    {
        static void Main(string[] args)
        {
            RBI objRBI = new RBI(100000);
            objRBI.UnderBalance += new AccountHandler(AxisBank.Penalty);
            objRBI.OverBalance += new AccountHandler(AxisBank.PayTax);
            //
            //objRBI.Withdraw(99999);
            objRBI.Deposit(500001);
            //
            Console.Read();
        }
        static void Penalty()
        {
            Console.WriteLine("AxisBank: Penalty Function.");
        }
        static void PayTax()
        {
            Console.WriteLine("AxisBank: PayTax Function.");
        }
    }
}
