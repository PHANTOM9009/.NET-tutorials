﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Events_Delegates_RBI_Example
{
    delegate void AccountHandler();
    internal class RBI
    {
        int balance;
        internal event AccountHandler UnderBalance;
        internal event AccountHandler OverBalance;
        public RBI(int balance) 
        {
            this.balance = balance;
        }

        internal void Withdraw(int amount)
        {
            balance -= amount;
            if (balance < 1000)
            {
                //Penalty
                UnderBalance();
            }
        }
        internal void Deposit(int amount)
        {
            int amountToDeposit = amount;
            if (amountToDeposit > 500000)
            {
                //Tax
                OverBalance();
            }
        }
    }
}
