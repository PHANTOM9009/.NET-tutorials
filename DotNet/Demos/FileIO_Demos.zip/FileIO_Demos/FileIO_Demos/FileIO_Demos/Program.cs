﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileIO_DNC_Demos
{
    class Program
    {
        static void Main(string[] args)
        {
            //File and FileInfo Features:-----
            //CreateFile();
            WriteFile();
            //ReadFile();
            //DeleteFile();
            //MoveFile();
            //
            //Directory and DirectoryInfo Features:-----
            //CreateDirectory();
            //GetFilesFromDirectory();
            //DeleteDirectory();
            //MoveDirectory();
            //
            Console.ReadLine();
        }

        static void CreateFile()
        {
            FileStream objFS = new FileStream(@"E:\ForFileIO\MyTextFile.txt", FileMode.Create,
                FileAccess.Write, FileShare.Read);
            Console.WriteLine("File Created.");
            objFS.Close();
        }

        static void WriteFile()
        {
            FileStream objFS = new FileStream(@"E:\ForFileIO\MyTextFile.txt", FileMode.Append,
                FileAccess.Read, FileShare.Read);
            StreamWriter objSW = new StreamWriter(objFS);
            objSW.WriteLine("Hello World!");
            objSW.Close();
            objFS.Close();
            Console.WriteLine("Data written in the file.");
        }

        static void ReadFile()
        {
            FileStream objFS = new FileStream(@"E:\ForFileIO\MyTextFile.txt", FileMode.Open,
                FileAccess.Read, FileShare.Read);
            StreamReader objSR = new StreamReader(objFS);
            string strFileContent = objSR.ReadToEnd();
            objSR.Close();
            objFS.Close();
            Console.WriteLine("----Contents from the file.-----");
            Console.WriteLine(strFileContent);
        }

        static void DeleteFile()
        {
            string filePath = @"E:\ForFileIO\MyTextFile.txt";
            if (File.Exists(filePath))
            {
                File.Delete(filePath);
                Console.WriteLine("File Deleted.");
            }
            else
            {
                Console.WriteLine("File doesn't exist.");
            }
            /*
            string filePath = @"E:\ForFileIO\MyTextFile.txt";
            FileInfo objFileInfo = new FileInfo(filePath);
            if (objFileInfo.Exists)
            {
                objFileInfo.Delete();
                Console.WriteLine("File Deleted.");
            }
            else
            {
                Console.WriteLine("File doesn't exist.");
            }
            */
        }

        static void MoveFile()
        {
            string sourceFilePath = @"E:\ForFileIO\MyTextFile.txt";
            string destinationFilePath = @"E:\ForFileIO\DestinationFolder\MyTextFile.txt";
            if (File.Exists(sourceFilePath))
            {
                File.Move(sourceFilePath, destinationFilePath);
                Console.WriteLine("File Moved.");
            }
            else
            {
                Console.WriteLine("File doesn't exist.");
            }
            /*
            string sourceFilePath = @"F:\ForFileIO\MyTextFile.txt";
            string destinationFilePath = @"F:\ForFileIO\DestinationFolder\MyTextFile.txt";
            FileInfo objFileInfo = new FileInfo(sourceFilePath);
            if (objFileInfo.Exists)
            {
                objFileInfo.MoveTo(destinationFilePath);
                Console.WriteLine("File Moved.");
            }
            else
            {
                Console.WriteLine("File doesn't exist.");
            }
            */
        }

        static void CreateDirectory()
        {
            string strDirectoryPath = @"E:\ForFileIO\MyDirectory";
            DirectoryInfo objDI = Directory.CreateDirectory(strDirectoryPath);
            if (objDI != null)
            {
                Console.WriteLine("Directory created.");
            }
            else
            {
                Console.WriteLine("Directory couldn't be created.");
            }
        }

        static void GetFilesFromDirectory()
        {
            string strDirectoryPath = @"E:\ForFileIO\MyDirectory";
            string[] strFiles = Directory.GetFiles(strDirectoryPath);
            Console.WriteLine("List of Files from the Directory: -----");
            foreach (var strFile in strFiles)
            {
                Console.WriteLine("File Name: " + Path.GetFileName(strFile));
                Console.WriteLine("File Extension: " + Path.GetExtension(strFile));
                Console.WriteLine("File Directory Name: " + Path.GetDirectoryName(strFile));
                //Console.WriteLine(strFile);
                Console.ReadLine();
            }
        }

        static void DeleteDirectory()
        {
            string directoryPath = @"E:\ForFileIO\MyDirectory";
            if (Directory.Exists(directoryPath))
            {
                Directory.Delete(directoryPath);
                Console.WriteLine("Directory Deleted.");
            }
            else
            {
                Console.WriteLine("Directory doesn't exist.");
            }
        }

        static void MoveDirectory()
        {
            string sourceDirectoryPath = @"E:\ForFileIO\MyDirectory";
            string destinationDirectoryPath = @"E:\ForFileIO\DestinationFolder\MyDirectory";
            DirectoryInfo objDirectoryInfo = new DirectoryInfo(sourceDirectoryPath);
            if (objDirectoryInfo.Exists)
            {
                objDirectoryInfo.MoveTo(destinationDirectoryPath);
                //objDirectoryInfo.Delete();
                Console.WriteLine("Directory Moved.");
            }
            else
            {
                Console.WriteLine("Directory doesn't exist.");
            }
        }
    }
}
