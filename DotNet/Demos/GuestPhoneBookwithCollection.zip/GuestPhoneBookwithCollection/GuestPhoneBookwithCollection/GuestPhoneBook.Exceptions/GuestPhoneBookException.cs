﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuestPhoneBook.Exceptions
{
    public class GuestPhoneBookException:ApplicationException
    {
        public GuestPhoneBookException()
            : base()
        {
            //Logic to log exception in a flat file
        }

        public GuestPhoneBookException(string message)
            : base(message)
        {
            //Logic to log exception in a db
        }
        public GuestPhoneBookException(string message, Exception innerException)
            : base(message, innerException)
        {
            //Logic to log exception in an xml file
        }
    }
}
