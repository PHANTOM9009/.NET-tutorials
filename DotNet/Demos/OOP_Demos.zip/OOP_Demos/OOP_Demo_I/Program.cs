﻿namespace OOP_Demo_I
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Rectangle objRectangle = new Rectangle();
            objRectangle.Length = 500;
            objRectangle.Breadth = 100;
            objRectangle.CalculateArea();
            objRectangle.CalculatePerimeter();
            Console.WriteLine("Area of Rectangle: " + objRectangle.Area);
            Console.WriteLine("Perimeter of Rectangle: " + objRectangle.Perimeter);
            //
            Console.ReadLine();
        }
    }
}