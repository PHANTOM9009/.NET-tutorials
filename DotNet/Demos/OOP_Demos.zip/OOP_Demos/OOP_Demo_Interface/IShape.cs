﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Demo_Interface
{
    internal interface IShape
    {
        public int Area { get; set; }
        public int Perimeter { get; set; }

        internal void CalculateArea();
        internal void CalculatePerimeter();
    }
}
