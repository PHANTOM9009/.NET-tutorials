﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Demo_Interface
{
    internal class Rectangle:IShape
    {
        private int length;
        private int breadth;

        public int Length
        {
            get
            {
                return length;
            }
            set
            {
                if (value > 0)
                {
                    length = value;
                }
            }
        }
        public int Breadth
        {
            get
            {
                return breadth;
            }
            set
            {
                if (value > 0)
                {
                    breadth = value;
                }
            }
        }
        public int Area { get; set; }
        public int Perimeter { get; set; }

        public void CalculateArea()
        {
            //base.CalculateArea();
            Area = Length * Breadth;
        }
        public void CalculatePerimeter()
        {
            //base.CalculatePerimeter();
            Perimeter = 2 * (Length + Breadth);
        }
    }
}
