﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Demo_StaticClass
{
    internal static class Database
    {
        public static string ConnectionString
        {
            get 
            {
                return "server=.;database=mydb;integrated security=true";
            }
        }
    }
}
