﻿namespace OOP_Demo_StaticClass
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Connection String: " + Database.ConnectionString);
            //
            Console.ReadLine();
        }
    }
}
