﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TaskProgramming
{
    class BankAccount
    {
        public int _balance = 0;
        public int Balance 
        {
            get
            {
                return _balance;
            }
            set
            {
                _balance = value;
            }
        }
    }
}
