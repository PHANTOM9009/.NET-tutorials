﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Remoting.Contexts;

namespace TaskProgramming
{
    [Synchronization]
    class BankAccountSyncContext:ContextBoundObject
    {
        private int balance = 0;
        public void IncrementBalance()
        {
            balance++;
        }
        public int GetBalance()
        {
            return balance;
        }
    }
}
