﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using System.Threading;

namespace TaskProgramming
{
    class ConcurrentCollectionClasses
    {
        static void Main(string[] args)
        {
            Dictionary<int,string> obj = new Dictionary<int,string>();
            //DataRaceSharingCollection();
            //ConcurrentQueueClass();
            //ConcurrentStackClass();
            ConcurrentBagClass();
        }

        static void DataRaceSharingCollection()
        {
            // create a shared collection
            Queue<int> sharedQueue = new Queue<int>();
            // populate the collection with items to process
            for (int i = 0; i < 1000; i++)
            {
                sharedQueue.Enqueue(i);
            }
            // define a counter for the number of processed items
            int itemCount = 0;
            // create tasks to process the list
            Task[] tasks = new Task[10];
            for (int i = 0; i < tasks.Length; i++)
            {
                // create the new task
                tasks[i] = new Task(() =>
                {
                    while (sharedQueue.Count > 0)
                    {
                        // take an item from the queue
                        int item = sharedQueue.Dequeue();
                        // increment the count of items processed
                        Interlocked.Increment(ref itemCount);
                    }
                });
                // start the new task
                tasks[i].Start();
            }
            // wait for the tasks to complete
            Task.WaitAll(tasks);
            // report on the number of items processed
            Console.WriteLine("Items processed: {0}", itemCount);
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void ConcurrentQueueClass()
        {
            // create a shared collection
            ConcurrentQueue<int> sharedQueue = new ConcurrentQueue<int>();
            // populate the collection with items to process
            for (int i = 0; i < 1000; i++)
            {
                sharedQueue.Enqueue(i);
            }
            // define a counter for the number of processed items
            int itemCount = 0;
            // create tasks to process the list
            Task[] tasks = new Task[10];
            for (int i = 0; i < tasks.Length; i++)
            {
                // create the new task
                tasks[i] = new Task(() =>
                {
                    while (sharedQueue.Count > 0)
                    {
                        // define a variable for the dequeue requests
                        int queueElement;
                        // take an item from the queue
                        bool gotElement = sharedQueue.TryDequeue(out queueElement);
                        // increment the count of items processed
                        if (gotElement)
                        {
                            Interlocked.Increment(ref itemCount);
                        }
                    }
                });
                // start the new task
                tasks[i].Start();
            }
            // wait for the tasks to complete
            Task.WaitAll(tasks);
            // report on the number of items processed
            Console.WriteLine("Items processed: {0}", itemCount);
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void ConcurrentStackClass()
        {
            // create a shared collection
            ConcurrentStack<int> sharedStack = new ConcurrentStack<int>();
            // populate the collection with items to process
            for (int i = 0; i < 1000; i++)
            {
                sharedStack.Push(i);
            }
            // define a counter for the number of processed items
            int itemCount = 0;
            // create tasks to process the list
            Task[] tasks = new Task[10];
            for (int i = 0; i < tasks.Length; i++)
            {
                // create the new task
                tasks[i] = new Task(() =>
                {
                    while (sharedStack.Count > 0)
                    {
                        // define a variable for the dequeue requests
                        int queueElement;
                        // take an item from the queue
                        bool gotElement = sharedStack.TryPop(out queueElement);
                        // increment the count of items processed
                        if (gotElement)
                        {
                            Interlocked.Increment(ref itemCount);
                        }
                    }
                });
                // start the new task
                tasks[i].Start();
            }
            // wait for the tasks to complete
            Task.WaitAll(tasks);
            // report on the number of items processed
            Console.WriteLine("Items processed: {0}", itemCount);
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void ConcurrentBagClass()
        {
            // create a shared collection
            ConcurrentBag<int> sharedBag = new ConcurrentBag<int>();
            // populate the collection with items to process
            for (int i = 0; i < 1000; i++)
            {
                sharedBag.Add(i);
            }
            // define a counter for the number of processed items
            int itemCount = 0;
            // create tasks to process the list
            Task[] tasks = new Task[10];
            for (int i = 0; i < tasks.Length; i++)
            {
                // create the new task
                tasks[i] = new Task(() =>
                {
                    while (sharedBag.Count > 0)
                    {
                        // define a variable for the dequeue requests
                        int queueElement;
                        // take an item from the queue
                        bool gotElement = sharedBag.TryTake(out queueElement);
                        // increment the count of items processed
                        if (gotElement)
                        {
                            Interlocked.Increment(ref itemCount);
                        }
                    }
                });
                // start the new task
                tasks[i].Start();
            }
            // wait for the tasks to complete
            Task.WaitAll(tasks);
            // report on the number of items processed
            Console.WriteLine("Items processed: {0}", itemCount);
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void ConcurrentDictionaryClass()
        {
            // create the bank account instance
            BankAccount account = new BankAccount();
            // create a shared dictionary
            ConcurrentDictionary<object, int> sharedDict
            = new ConcurrentDictionary<object, int>();
            // create tasks to process the list
            Task<int>[] tasks = new Task<int>[10];
            for (int i = 0; i < tasks.Length; i++)
            {
                // put the initial value into the dictionary
                sharedDict.TryAdd(i, account.Balance);
                // create the new task
                tasks[i] = new Task<int>((keyObj) =>
                {
                    // define variables for use in the loop
                    int currentValue;
                    bool gotValue;
                    // enter a loop for 1000 balance updates
                    for (int j = 0; j < 1000; j++)
                    {
                        // get the current value from the dictionary
                        gotValue = sharedDict.TryGetValue(keyObj, out currentValue);
                        // increment the value and update the dictionary entry
                        sharedDict.TryUpdate(keyObj, currentValue + 1, currentValue);
                    }// define the final result
                    int result;
                    // get our result from the dictionary
                    gotValue = sharedDict.TryGetValue(keyObj, out result);
                    // return the result value if we got one
                    if (gotValue)
                    {
                        return result;
                    }
                    else
                    {
                        // there was no result available - we have encountered a problem
                        throw new Exception(
                        String.Format("No data item available for key {0}", keyObj));
                    }
                }, i);
                // start the new task
                tasks[i].Start();
            }
            // update the balance of the account using the task results
            for (int i = 0; i < tasks.Length; i++)
            {
                account.Balance += tasks[i].Result;
            }
            // write out the counter value
            Console.WriteLine("Expected value {0}, Balance: {1}",
            10000, account.Balance);
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }
    }
}