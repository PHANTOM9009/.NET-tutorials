﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TaskProgramming
{
    class PLINQQueries
    {
        static void Main(string[] args)
        {
            LINQAndPLINQ_Queries();
            //PLINQFilteringQuery();
            //PreservingOrderInParallelQuery();
            //ForcingImmediateQueryExecution();
            //LimitingDegreeOfParallelismForAQuery();
            //UsingAsSequentialExtensionMethod();
            //CancellingPLINQQueries();
            //
            Console.ReadLine();
        }

        static void LINQAndPLINQ_Queries()
        {
            // create some source data
            int[] sourceData = new int[10];
            for (int j = 0; j < sourceData.Length; j++)
            {
                sourceData[j] = j;
            }
            // define a sequential linq query
            IEnumerable<double> results1 =
            from item in sourceData
            select Math.Pow(item, 2);


            // enumerate the results of the sequential query
            foreach (double d in results1)
            {
                Console.WriteLine("Sequential result: {0}", d);
            }
            // define a parallel linq query
            IEnumerable<double> results2 =
            from item in sourceData.AsParallel()
            select Math.Pow(item, 2);
            // enumerate the results of the parallel query
            foreach (double d in results2)
            {
                Console.WriteLine("Parallel result: {0}", d);
            }
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
            int[,] i = new int[2, 5] { {1, 2, 3, 4, 5 }, { 1, 2, 3, 4, 5 } };
        }

        static void PLINQFilteringQuery()
        {
            // create some source data
            int[] sourceData = new int[100000];
            for (int i = 0; i < sourceData.Length; i++)
            {
                sourceData[i] = i;
            }
            // define a filtering query using keywords
            IEnumerable<double> results1
            = from item in sourceData.AsParallel()
              where item % 2 == 0
              select Math.Pow(item, 2);
            // enumerate the results
            foreach (var d in results1)
            {
                Console.WriteLine("Result: {0}", d);
            }
            // define a filtering query using extension methods
            IEnumerable<double> results2
            = sourceData.AsParallel()
            .Where(item => item % 2 == 0)
            .Select(item => Math.Pow(item, 2));
            // enumerate the results
            foreach (var d in results2)
            {
                Console.WriteLine("Result: {0}", d);
            }
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void PreservingOrderInParallelQuery()
        {
            // create some source data
            int[] sourceData = new int[10];
            for (int i = 0; i < sourceData.Length; i++)
            {
                sourceData[i] = i;
            }
            // preserve order with the AsOrdered() method
            IEnumerable<double> results =
            from item in sourceData.AsParallel().AsOrdered()
            select Math.Pow(item, 2);
            // enumerate the results of the parallel query
            foreach (double d in results)
            {
                Console.WriteLine("Parallel result: {0}", d);
            }
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void ForcingImmediateQueryExecution()
        {
            // create some source data
            int[] sourceData = new int[10];
            for (int i = 0; i < sourceData.Length; i++)
            {
                sourceData[i] = i;
            }
            Console.WriteLine("Defining PLINQ query");
            // define the query
            IEnumerable<double> results =
            sourceData.AsParallel().Select(item =>
            {
                Console.WriteLine("Processing item {0}", item);
                return Math.Pow(item, 2);
            }).ToArray();
            Console.WriteLine("Waiting...");
            Thread.Sleep(5000);
            // sum the results - this will trigger
            // execution of the query
            Console.WriteLine("Accessing results");
            double total = 0;
            foreach (double d in results)
            {
                total += d;
            }
            Console.WriteLine("Total {0}", total);
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void LimitingDegreeOfParallelismForAQuery()
        {
            // create some source data
            int[] sourceData = new int[10];
            for (int i = 0; i < sourceData.Length; i++)
            {
                sourceData[i] = i;
            }
            // define the query and force parallelism
            IEnumerable<double> results =
            sourceData.AsParallel()
            .WithDegreeOfParallelism(2)
            .Where(item => item % 2 == 0)
            .Select(item => Math.Pow(item, 2));
            // enumerate the results
            foreach (double d in results)
            {
                Console.WriteLine("Result {0}", d);
            }
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void UsingAsSequentialExtensionMethod()
        {
            // create some source data
            int[] sourceData = new int[10];
            for (int i = 0; i < sourceData.Length; i++)
            {
                sourceData[i] = i;
            }
            // define the query and force parallelism
            IEnumerable<double> results =
            sourceData.AsParallel()
            .WithDegreeOfParallelism(2)
            .Where(item => item % 2 == 0)
            .Select(item => Math.Pow(item, 2))
            .AsSequential()
            .Select(item => item * 2);
            // enumerate the results
            foreach (double d in results)
            {
                Console.WriteLine("Result {0}", d);
            }// wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void CancellingPLINQQueries()
        {
            // create a cancellation token source
            CancellationTokenSource tokenSource
            = new CancellationTokenSource();// create some source data
            int[] sourceData = new int[1000000];
            for (int i = 0; i < sourceData.Length; i++)
            {
                sourceData[i] = i;
            }
            // define a query that supports cancellation
            IEnumerable<double> results = sourceData
            .AsParallel()
            .WithCancellation(tokenSource.Token)
            .Select(item =>
            {
                // return the result value
                return Math.Pow(item, 2);
            });
            // create a task that will wait for 5 seconds
            // and then cancel the token
            Task.Factory.StartNew(() =>
            {
                Thread.Sleep(5000);
                tokenSource.Cancel();
                Console.WriteLine("Token source cancelled");
            });
            try
            {
                // enumerate the query results
                foreach (double d in results)
                {
                    Console.WriteLine("Result: {0}", d);
                }
            }
            catch (OperationCanceledException)
            {
                Console.WriteLine("Caught cancellation exception");
            }// wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }
    }
}
