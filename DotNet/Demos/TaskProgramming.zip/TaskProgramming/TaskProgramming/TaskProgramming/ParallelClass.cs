﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TaskProgramming
{
    class ParallelClass
    {
        static void Main(string[] args)
        {
            //UsingParallelInvoke();
            //BasicParallelForLoop();
            UsingParallelForEach();
            //CreatingSteppedLoop();
            //OptionsForParallelLoop();
            //StopParallelLoop();
            //BreakParallelLoop();
            //ParallelLoopResultStructure();
            //CancellingParallelLoop();
        }

        static void UsingParallelInvoke()
        {
            Action objDisplay = new Action(Display);
            Parallel.Invoke(objDisplay);

            // invoke actions described by lambda expressions
            Parallel.Invoke(
            () => Console.WriteLine("Action 1"),
            () => Console.WriteLine("Action 2"),
            () => Console.WriteLine("Action 3"));
            // explicitly create an array of actions
            Action[] actions = new Action[3];
            actions[0] = new Action(() => Console.WriteLine("Action 4"));
            actions[1] = new Action(() => Console.WriteLine("Action 5"));
            actions[2] = new Action(() => Console.WriteLine("Action 6"));
            // invoke the actions array
            Parallel.Invoke(actions);
            // create the same effect using tasks explicitly
            Task parent = Task.Factory.StartNew(() =>
            {
                foreach (Action action in actions)
                {
                    Task.Factory.StartNew(action, TaskCreationOptions.AttachedToParent);
                }
            });
            // wait for the task to finish
            parent.Wait();
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void BasicParallelForLoop()
        {
            Parallel.For(0, 10, index =>
            {
                Console.WriteLine("Task ID {0} processing index: {1}",
                Task.CurrentId, index);
            });// wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void UsingParallelForEach()
        {
            // create a collection of strings
            List<string> dataList = new List<string> {
            "the", "quick", "brown", "fox", "jumps", "etc"
            };
            // process the elements of the collection
            // using a parallel foreach loop
            Parallel.ForEach(dataList, item =>
            {
                Console.WriteLine("Item {0} has {1} characters",
                item, item.Length);
            });
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void CreatingSteppedLoop()
        {
            Parallel.ForEach(SteppedIterator(0, 10, 2), index =>
            {
                Console.WriteLine("Index value: {0}", index);
            });
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static IEnumerable<int> SteppedIterator(int startIndex,int endEndex, int stepSize)
        {
            for (int i = startIndex; i < endEndex; i += stepSize)
            {
                yield return i;
            }
        }

        static void OptionsForParallelLoop()
        {
            // create a ParallelOptions instance
            // and set the max concurrency to 1
            ParallelOptions options
            = new ParallelOptions() { MaxDegreeOfParallelism = 1 };
            // perform a parallel for loop
            Parallel.For(0, 10, options, index =>
            {
                Console.WriteLine("For Index {0} started", index);
                Thread.Sleep(500);
                Console.WriteLine("For Index {0} finished", index);
            });
            // create an array of ints to process
            int[] dataElements = new int[] { 0, 2, 4, 6, 8 };
            // perform a parallel foreach loop
            Parallel.ForEach(dataElements, options, index =>
            {
                Console.WriteLine("ForEach Index {0} started", index);
                Thread.Sleep(500);
                Console.WriteLine("ForEach Index {0} finished", index);
            });
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void StopParallelLoop()
        {
            List<string> dataItems = new List<string>() { "an", "apple", "a", "day", "keeps", "the", "doctor", "away" };
            Parallel.ForEach(dataItems, (string item, ParallelLoopState state) =>
            {
                if (item.Contains("k"))
                {
                    Console.WriteLine("Hit: {0}", item);
                    state.Stop();
                }
                else
                {
                    Console.WriteLine("Miss: {0}", item);
                }
            });
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void BreakParallelLoop()
        {
            ParallelLoopResult res = Parallel.For(0, 100,
            (int index, ParallelLoopState loopState) =>
            {
                // calculate the square of the index
                double sqr = Math.Pow(index, 2);
                // if the square value is > 100 then break
                if (sqr > 100)
                {
                    Console.WriteLine("Breaking on index {0}", index);
                    loopState.Break();
                }
                else
                {
                    // write out the value
                    Console.WriteLine("Square value of {0} is {1}", index, sqr);
                }
            });
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void ParallelLoopResultStructure()
        {
            // run a parallel loop in which one of
            // the iterations calls Stop()
            ParallelLoopResult loopResult =
            Parallel.For(0, 10, (int index, ParallelLoopState loopState) =>
            {
                if (index == 2)
                {
                    //loopState.Stop();
                    loopState.Break();
                }
            });
            // get the details from the loop result
            Console.WriteLine("Loop Result");
            Console.WriteLine("IsCompleted: {0}", loopResult.IsCompleted);
            Console.WriteLine("BreakValue: {0}", loopResult.LowestBreakIteration.HasValue);
            Console.WriteLine("BreakValue: {0}", loopResult.LowestBreakIteration.Value);
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void CancellingParallelLoop()
        {
            // create a cancellation token source
            CancellationTokenSource tokenSource
            = new CancellationTokenSource();
            // start a task that will cancel the token source
            // after a few seconds sleep
            Task.Factory.StartNew(() =>
            {
                // sleep for 5 seconds
                Thread.Sleep(5000);
                // cancel the token source
                tokenSource.Cancel();
                // let the user know
                Console.WriteLine("Token cancelled");
            });
            // create loop options with a token
            ParallelOptions loopOptions =
            new ParallelOptions()
            {
                CancellationToken = tokenSource.Token
            };
            try
            {
                // perform a parallel loop specifying the options
                // make this a loop that will take a while to complete
                // so the user has time to cancel
                Parallel.For(0, Int64.MaxValue, loopOptions, index =>
                {
                    // do something just to occupy the cpu for a little
                    double result = Math.Pow(index, 3);
                    // write out the current index
                    Console.WriteLine("Index {0}, result {1}", index, result);
                    // put the thread to sleep, just to slow things down
                    Thread.Sleep(100);
                });
            }
            catch (OperationCanceledException)
            {
                Console.WriteLine("Caught cancellation exception...");
            }
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void Display()
        {
            Console.WriteLine("Hello World!");
        }


    }
}
