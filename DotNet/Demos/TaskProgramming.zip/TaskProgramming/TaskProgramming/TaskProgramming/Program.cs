﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace TaskProgramming
{
    class Program
    {
        static void Main(string[] args)
        {
            //Task.Factory.StartNew(() =>
            //{
            //    Console.WriteLine("Hello World");
            //});
            //// wait for input before exiting
            //Console.WriteLine("Main method complete. Press enter to finish.");
            //Console.ReadLine();
            //
            //FourWaysToCreateBasicTask();//-----I
            //AddingTaskState_FourDifferentWays();//-----II
            GettingResultFromTask();//-----III
            //GettingResultFromTask_UsingTaskFactory();
            //CancellingTask_PollingToCheckCancellation();//-----IV
            //MonitoringCancellationWithDelegate();//-----IV
            //CancellingMonitoringUsingWaitHandle();//-----V
            //CancellingSeveralTasks();//-----VI
            //CompositeCancellationToken();//-----VII
            //PuttingTaskToSleep();//-----VII
            //WaitingForASingleTask();//-----VIII
            //WaitForSeveralTasks();//-----IX
            //BasicExceptionHandling();//-----X
            //IterativeExceptionHandler();//-----XI
            //LazyTaskExecution();//-----XII
            //TaskDependencyDeadlock();//-----XIII
            //LocalVariableEvaluation();//-----XIV
            //
            Console.ReadLine();
        }

        static void printMessage()
        {
            Console.WriteLine("Hello World : " + Task.CurrentId);
        }

        static void printMessage(object message)
        {
            Console.WriteLine("Message: {0}", message);
        }

        static void FourWaysToCreateBasicTask()
        {
            // use an Action delegate and a named method - I
            Task task1 = new Task(new Action(printMessage));

            // use a anonymous delegate - II
            Task task2 = new Task(delegate
            {
                printMessage();
                //Console.WriteLine("Hello World");
            });

            // use a lambda expression and a named method - III
            Task task3 = new Task(() => printMessage());

            // use a lambda expression and an anonymous method - IV
            Task task4 = new Task(() =>
            {
                printMessage();
                //Console.WriteLine("Hello World");
            });
            //
            task1.Start();
            task2.Start();
            task3.Start();
            task4.Start();

            // wait for input before exiting
            Console.WriteLine("Main method complete. Press enter to finish.");
            Console.ReadLine();
        }

        static void AddingTaskState_FourDifferentWays()
        {
            // use an Action delegate and a named method - I
            Task task1 = new Task(new Action<object>(printMessage),
            "First task");
            // use a anonymous delegate - II
            Task task2 = new Task(delegate(object obj)
            {
                printMessage(obj);
            }, "Second Task");
            // use a lambda expression and a named method
            // note that parameters to a lambda don’t need
            // to be quoted if there is only one parameter - III
            Task task3 = new Task((obj) => printMessage(obj), "Third task");
            // use a lambda expression and an anonymous method - IV
            Task task4 = new Task((obj) =>
            {
                printMessage(obj);
            }, "Fourth task");
            //
            task1.Start();
            task2.Start();
            task3.Start();
            task4.Start();
            // wait for input before exiting
            Console.WriteLine("Main method complete. Press enter to finish.");
            Console.ReadLine();
        }

        static void GettingResultFromTask()
        {
            Task<int> taskNew = new Task<int>(delegate
            {
                int sum = 0;
                for (int i = 0; i < 50; i++)
                {
                    sum += i;
                }
                Console.WriteLine("Current TaskID: " + Task.CurrentId);
                return sum;
            });
            taskNew.Start();
            Console.WriteLine("Result 1: {0}", taskNew.Result);

            // create the task
            Task<int> task1 = new Task<int>(() =>
            {
                int sum = 0;
                for (int i = 0; i < 100; i++)
                {
                    sum += i;
                }
                Console.WriteLine("Current TaskID: " + Task.CurrentId);
                return sum;
            });
            // start the task
            task1.Start();
            // write out the result
            Console.WriteLine("Result 1: {0}", task1.Result);

            // create the task using state
            Task<int> task2 = new Task<int>(obj =>
            {
                int sum = 0;
                int max = (int)obj;
                for (int i = 0; i < max; i++)
                {
                    sum += i;
                }
                Console.WriteLine("Current TaskID: " + Task.CurrentId);
                return sum;
            },100);
            // start the task
            task2.Start();
            // write out the result
            Console.WriteLine("Result 2: {0}", task2.Result);
            // wait for input before exiting
            Console.WriteLine("Main method complete. Press enter to finish.");
            Console.ReadLine();
        }

        static void GettingResultFromTask_UsingTaskFactory()
        {
            // create the task
            Task<int> task1 = Task.Factory.StartNew<int>(() =>
            {
                int sum = 0;
                for (int i = 0; i < 100; i++)
                {
                    sum += i;
                }
                return sum;
            });
            // write out the result
            Console.WriteLine("Result 1: {0}", task1.Result);
            // wait for input before exiting
            Console.WriteLine("Main method complete. Press enter to finish.");
            Console.ReadLine();
        }

        static void CancellingTask_PollingToCheckCancellation()
        {
            // create the cancellation token source
            CancellationTokenSource tokenSource
            = new CancellationTokenSource();
            // create the cancellation token
            CancellationToken token = tokenSource.Token;
            // create the task
            Task task = new Task(() =>
            {
                for (int i = 0; i < int.MaxValue; i++)
                {
                    if (token.IsCancellationRequested)
                    {
                        Console.WriteLine("Task cancel detected");
                        throw new OperationCanceledException(token);
                    }
                    else
                    {
                        Console.WriteLine("Int value {0}", i);
                    }
                }
            }, token);
            // wait for input before we start the task
            Console.WriteLine("Press enter to start task");
            Console.WriteLine("Press enter again to cancel task");
            Console.ReadLine();
            // start the task
            task.Start();
            // read a line from the console.
            Console.ReadLine();
            // cancel the task
            Console.WriteLine("Cancelling task");
            tokenSource.Cancel();
            // wait for input before exiting
            Console.WriteLine("Main method complete. Press enter to finish.");
            Console.ReadLine();
        }

        //use the delegate feature to be notified when a cancellation happens; this can be useful in UI applications.
        static void MonitoringCancellationWithDelegate()
        {
            // create the cancellation token source
            CancellationTokenSource tokenSource
            = new CancellationTokenSource();
            // create the cancellation token
            CancellationToken token = tokenSource.Token;
            // create the task
            Task task = new Task(() =>
            {
                for (int i = 0; i < int.MaxValue; i++)
                {
                    if (token.IsCancellationRequested)
                    {
                        Console.WriteLine("Task cancel detected");
                        throw new OperationCanceledException(token);
                    }
                    else
                    {
                        Console.WriteLine("Int value {0}", i);
                    }
                }
            }, token);
            // register a cancellation delegate
            token.Register(() =>
            {
                Console.WriteLine(">>>>>> Delegate Invoked\n");
            });
            // wait for input before we start the task
            Console.WriteLine("Press enter to start task");
            Console.WriteLine("Press enter again to cancel task");
            Console.ReadLine();
            // start the task
            task.Start();
            // read a line from the console.
            Console.ReadLine();
            // cancel the task
            Console.WriteLine("Cancelling task");
            tokenSource.Cancel();
            // wait for input before exiting
            Console.WriteLine("Main method complete. Press enter to finish.");
            Console.ReadLine();
        }

        static void CancellingMonitoringUsingWaitHandle()
        {
            // create the cancellation token source
            CancellationTokenSource tokenSource
            = new CancellationTokenSource();
            // create the cancellation token
            CancellationToken token = tokenSource.Token;
            // create the task
            Task task1 = new Task(() =>
            {
                for (int i = 0; i < int.MaxValue; i++)
                {
                    if (token.IsCancellationRequested)
                    {
                        Console.WriteLine("Task cancel detected");
                        throw new OperationCanceledException(token);
                    }
                    else
                    {
                        Console.WriteLine("Int value {0}", i);
                    }
                }
            }, token);
            // create a second task that will use the wait handle
            Task task2 = new Task(() =>
            {
                // wait on the handle
                token.WaitHandle.WaitOne();
                // write out a message
                Console.WriteLine(">>>>> Wait handle released");
            });
            // wait for input before we start the task
            Console.WriteLine("Press enter to start task");
            Console.WriteLine("Press enter again to cancel task");
            Console.ReadLine();
            // start the tasks
            task1.Start();
            task2.Start();
            // read a line from the console.
            Console.ReadLine();
            // cancel the task
            Console.WriteLine("Cancelling task");
            tokenSource.Cancel();
            // wait for input before exiting
            Console.WriteLine("Main method complete. Press enter to finish.");
            Console.ReadLine();
        }

        static void CancellingSeveralTasks()
        {
            // create the cancellation token source
            CancellationTokenSource tokenSource
            = new CancellationTokenSource();
            // create the cancellation token
            CancellationToken token = tokenSource.Token;
            // create the tasks
            Task task1 = new Task(() =>
            {
                for (int i = 0; i < int.MaxValue; i++)
                {
                    token.ThrowIfCancellationRequested();
                    Console.WriteLine("Task 1 - Int value {0}", i);
                }
            }, token);
            Task task2 = new Task(() =>
            {
                for (int i = 0; i < int.MaxValue; i++)
                {
                    token.ThrowIfCancellationRequested();
                    Console.WriteLine("Task 2 - Int value {0}", i);
                }
            }, token);
            // wait for input before we start the tasks
            Console.WriteLine("Press enter to start tasks");
            Console.WriteLine("Press enter again to cancel tasks");
            Console.ReadLine();
            // start the tasks
            task1.Start();
            task2.Start();
            // read a line from the console.
            Console.ReadLine();
            // cancel the task
            Console.WriteLine("Cancelling tasks");
            tokenSource.Cancel();
            // wait for input before exiting
            Console.WriteLine("Main method complete. Press enter to finish.");
            Console.ReadLine();
        }

        static void CompositeCancellationToken()
        {
            // create the cancellation token sources
            CancellationTokenSource tokenSource1 = new CancellationTokenSource();
            CancellationTokenSource tokenSource2 = new CancellationTokenSource();
            CancellationTokenSource tokenSource3 = new CancellationTokenSource();
            // create a composite token source using multiple tokens
            CancellationTokenSource compositeSource =
            CancellationTokenSource.CreateLinkedTokenSource(
            tokenSource1.Token, tokenSource2.Token, tokenSource3.Token);
            // create a cancellable task using the composite token
            Task task = new Task(() =>
            {
                // wait until the token has been cancelled
                compositeSource.Token.WaitHandle.WaitOne();
                // throw a cancellation exception
                throw new OperationCanceledException(compositeSource.Token);
            }, compositeSource.Token);
            Task task2 = new Task(() =>
            {
                // wait until the token has been cancelled
                compositeSource.Token.WaitHandle.WaitOne();
                // throw a cancellation exception
                throw new OperationCanceledException(compositeSource.Token);
            }, compositeSource.Token);
            // start the task
            task.Start();
            task2.Start();
            // cancel one of the original tokens
            tokenSource2.Cancel();
            // write out the cancellation detail of each task
            Console.WriteLine("Task 1 cancelled? {0}", task.IsCanceled);
            Console.WriteLine("Task 2 cancelled? {0}", task2.IsCanceled);
            // wait for input before exiting
            Console.WriteLine("Main method complete. Press enter to finish.");
            Console.ReadLine();
            Console.WriteLine("Task 1 cancelled? {0}", task.IsCanceled);
            Console.WriteLine("Task 2 cancelled? {0}", task2.IsCanceled);
        }

        static void PuttingTaskToSleep()
        {
            // create the cancellation token source
            CancellationTokenSource tokenSource = new CancellationTokenSource();
            // create the cancellation token
            CancellationToken token = tokenSource.Token;
            // create the first task, which we will let run fully
            Task task1 = new Task(() =>
            {
                for (int i = 0; i < Int32.MaxValue; i++)
                {
                    // put the task to sleep for 10 seconds
                    bool cancelled = token.WaitHandle.WaitOne(10000);//We can even use Classic Sleep - Thread.Sleep(10000);
                    // print out a message
                    Console.WriteLine("Task 1 - Int value {0}. Cancelled? {1}",
                    i, cancelled);
                    // check to see if we have been cancelled
                    if (cancelled)
                    {
                        throw new OperationCanceledException(token);
                    }
                }
            }, token);
            // start task
            task1.Start();
            // wait for input before exiting
            Console.WriteLine("Press enter to cancel token.");
            Console.ReadLine();
            // cancel the token
            tokenSource.Cancel();
            // wait for input before exiting
            Console.WriteLine("Main method complete. Press enter to finish.");
            Console.ReadLine();
        }

        static void WaitingForASingleTask()
        {
            // create the cancellation token source
            CancellationTokenSource tokenSource = new CancellationTokenSource();
            // create the cancellation token
            CancellationToken token = tokenSource.Token;
            // create and start the first task, which we will let run fully
            Task task = createTask(token);
            task.Start();
            // wait for the task
            Console.WriteLine("Waiting for task to complete.");
            task.Wait();
            Console.WriteLine("Task Completed.");
            // create and start another task
            task = createTask(token);
            task.Start();
            Console.WriteLine("Waiting 2 secs for task to complete.");
            bool completed = task.Wait(2000);
            Console.WriteLine("Wait ended - task completed: {0}", completed);
            // create and start another task
            task = createTask(token);
            task.Start();
            Console.WriteLine("Waiting 2 secs for task to complete.");
            completed = task.Wait(2000, token);
            Console.WriteLine("Wait ended - task completed: {0} task cancelled {1}"
                , completed, task.IsCanceled);
            // wait for input before exiting
            Console.WriteLine("Main method complete. Press enter to finish.");
            Console.ReadLine();
        }

        static Task createTask(CancellationToken token)
        {
            return new Task(() =>
            {
                for (int i = 0; i < 5; i++)
                {
                    // check for task cancellation
                    token.ThrowIfCancellationRequested();
                    // print out a message
                    Console.WriteLine("Task - Int value {0}", i);
                    // put the task to sleep for 1 second
                    token.WaitHandle.WaitOne(1000);
                }
            }, token);
        }

        static void WaitForSeveralTasks()
        {
            // create the cancellation token source
            CancellationTokenSource tokenSource = new CancellationTokenSource();
            // create the cancellation token
            CancellationToken token = tokenSource.Token;
            // create the tasks
            Task task1 = new Task(() =>
            {
                for (int i = 0; i < 5; i++)
                {
                    // check for task cancellation
                    token.ThrowIfCancellationRequested();
                    // print out a message
                    Console.WriteLine("Task 1 - Int value {0}", i);
                    // put the task to sleep for 1 second
                    token.WaitHandle.WaitOne(1000);
                }
                Console.WriteLine("Task 1 complete");
            }, token);
            Task task2 = new Task(() =>
            {
                Console.WriteLine("Task 2 complete");
            }, token);
            // start the tasks
            task1.Start();
            task2.Start();
            // wait for the tasks
            Console.WriteLine("Waiting for tasks to complete.");
            Task.WaitAll(task1, task2);
            Console.WriteLine("Tasks Completed.");
            // wait for input before exiting
            Console.WriteLine("Main method complete. Press enter to finish.");
            Console.ReadLine();
        }

        static void BasicExceptionHandling()
        {
            // create the tasks
            Task task1 = new Task(() =>
            {
                ArgumentOutOfRangeException exception = new ArgumentOutOfRangeException();
                exception.Source = "task1";
                throw exception;
            });
            Task task2 = new Task(() =>
            {
                throw new NullReferenceException();
            });
            Task task3 = new Task(() =>
            {
                Console.WriteLine("Hello from Task 3");
            });
            // start the tasks
            task1.Start(); task2.Start(); task3.Start();
            // wait for all of the tasks to complete
            // and wrap the method in a try...catch block
            try
            {
                Task.WaitAll(task1, task2, task3);
            }
            catch (AggregateException ex)
            {
                // enumerate the exceptions that have been aggregated
                foreach (Exception inner in ex.InnerExceptions)
                {
                    Console.WriteLine("Exception type {0} from {1}",
                    inner.GetType(), inner.Source);
                }
            }
            // wait for input before exiting
            Console.WriteLine("Main method complete. Press enter to finish.");
            Console.ReadLine();
        }

        static void IterativeExceptionHandler()
        {
            // create the cancellation token source and the token
            CancellationTokenSource tokenSource = new CancellationTokenSource();
            CancellationToken token = tokenSource.Token;
            // create a task that waits on the cancellation token
            Task task1 = new Task(() =>
            {
                // wait forever or until the token is cancelled
                token.WaitHandle.WaitOne(-1);
                // throw an exception to acknowledge the cancellation
                throw new OperationCanceledException(token);
            }, token);
            // create a task that throws an exception
            Task task2 = new Task(() =>
            {
                throw new NullReferenceException();
            });
            // start the tasks
            task1.Start(); task2.Start();
            // cancel the token
            tokenSource.Cancel();
            // wait on the tasks and catch any exceptions
            try
            {
                Task.WaitAll(task1, task2);
            }
            catch (AggregateException ex)
            {
                // iterate through the inner exceptions using
                // the handle method
                ex.Handle((inner) =>
                {
                    if (inner is OperationCanceledException)
                    {
                        // ...handle task cancellation...
                        return true;
                    }
                    else
                    {
                        // this is an exception we don't know how
                        // to handle, so return false
                        return true;
                    }
                });
            }
            // wait for input before exiting
            Console.WriteLine("Main method complete. Press enter to finish.");
            Console.ReadLine();

            //-----Reading the Task Properties-----
            // write out the details of the task exception
            Console.WriteLine("Task 1 completed: {0}", task1.IsCompleted);
            Console.WriteLine("Task 1 faulted: {0}", task1.IsFaulted);
            Console.WriteLine("Task 1 cancelled: {0}", task1.IsCanceled);
            Console.WriteLine(task1.Exception);

            Console.WriteLine("Task 2 completed: {0}", task2.IsCompleted);
            Console.WriteLine("Task 2 faulted: {0}", task2.IsFaulted);
            Console.WriteLine("Task 2 cancelled: {0}", task2.IsCanceled);
            Console.WriteLine(task2.Exception);
        }

        static void LazyTaskExecution()
        {
            // define the function
            Func<string> taskBody = new Func<string>(() =>
            {
                Console.WriteLine("Task body working...");
                return "Task Result";
            });
            // create the lazy variable
            Lazy<Task<string>> lazyData = new Lazy<Task<string>>(() =>
            Task<string>.Factory.StartNew(taskBody));
            Console.WriteLine("Calling lazy variable");
            Console.WriteLine("Result from task: {0}", lazyData.Value.Result);
            // do the same thing in a single statement
            Lazy<Task<string>> lazyData2 = new Lazy<Task<string>>(
            () => Task<string>.Factory.StartNew(() =>
            {
                Console.WriteLine("Task body working...");
                return "Task Result";
            }));
            Console.WriteLine("Calling second lazy variable");
            Console.WriteLine("Result from task: {0}", lazyData2.Value.Result);
            // wait for input before exiting
            Console.WriteLine("Main method complete. Press enter to finish.");
            Console.ReadLine();
        }

        static void TaskDependencyDeadlock()
        {
            // define an array to hold the Tasks
            Task<int>[] tasks = new Task<int>[2];
            // create and start the first task
            tasks[0] = Task.Factory.StartNew(() =>
            {
                // get the result of the other task,
                // add 100 to it and return it as the result
                return tasks[1].Result + 100;
            });
            // create and start the second task
            tasks[1] = Task.Factory.StartNew(() =>
            {
                // get the result of the other task,
                // add 100 to it and return it as the result
                return tasks[1].Result + 100;
            });
            // wait for the tasks to complete
            Task.WaitAll(tasks);
            // wait for input before exiting
            Console.WriteLine("Main method complete. Press enter to finish.");
            Console.ReadLine();
        }

        //?
        static void LocalVariableEvaluation()
        {
            Console.WriteLine("Bad Task-----");
            // create and start the "bad" tasks
            for (int i = 0; i < 5; i++)
            {
                Task.Factory.StartNew(() =>
                {
                    // write out a message that uses the loop counter
                    Console.WriteLine("Task {0} has counter value: {1}",
                    Task.CurrentId, i);
                });
            }
            Console.WriteLine("Good Task-----");
            // create and start the "good" tasks
            for (int i = 0; i < 5; i++)
            {
                Task.Factory.StartNew((stateObj) =>
                {
                    // cast the state object to an int
                    int loopValue = (int)stateObj;
                    // write out a message that uses the loop counter
                    Console.WriteLine("Task {0} has counter value: {1}",
                    Task.CurrentId, loopValue);
                }, i);
            }
            // wait for input before exiting
            Console.WriteLine("Main method complete. Press enter to finish.");
            Console.ReadLine();
        }
    }
}
