﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TaskProgramming
{
    class SynchronizationDemo
    {
        static void Main(string[] args)
        {
            LockingAndMonitoring();//-----I
            //SingleLockObjectToSerializeAccessToTwoCriticalRegions();//-----II
            //InterlockedIncrement();//-----III
            //BasicUseOfMutexClass();//-----IV
            //MultipleLocksWithMutex_WaitAll();//-----V
            //InterprocessMutex();//-----VI
            //DeclarativeSynchronization();//-----VI
            //ReadWriteLocks();//-----VII
        }

        static void LockingAndMonitoring()
        {
            // create the bank account instance
            BankAccount account = new BankAccount();
            // create an array of tasks
            Task[] tasks = new Task[10];
            // create the lock object
            object lockObj = new object();
            for (int i = 0; i < 10; i++)
            {
                // create a new task
                tasks[i] = new Task(() =>
                {
                    // enter a loop for 1000 balance updates
                    for (int j = 0; j < 1000; j++)
                    {
                        lock (lockObj)
                        {
                            // update the balance
                            account.Balance = account.Balance + 1;
                        }
                    }
                });
                // start the new task
                tasks[i].Start();
            }
            // wait for all of the tasks to complete
            Task.WaitAll(tasks);
            // write out the counter value
            Console.WriteLine("Expected value {0}, Balance: {1}",
            10000, account.Balance);
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void SingleLockObjectToSerializeAccessToTwoCriticalRegions()
        {
            // create the bank account instance
            BankAccount account = new BankAccount();
            // create an array of tasks
            Task[] incrementTasks = new Task[5];
            Task[] decrementTasks = new Task[5];
            // create the lock object
            object lockObj = new object();
            for (int i = 0; i < 5; i++)
            {
                // create a new task
                incrementTasks[i] = new Task(() =>
                {
                    // enter a loop for 1000 balance updates
                    for (int j = 0; j < 1000; j++)
                    {
                        lock (lockObj)
                        {
                            // increment the balance
                            account.Balance++;
                        }
                    }
                });
                // start the new task
                incrementTasks[i].Start();
            }
            for (int i = 0; i < 5; i++)
            {
                // create a new task
                decrementTasks[i] = new Task(() =>
                {
                    // enter a loop for 1000 balance updates
                    for (int j = 0; j < 1000; j++)
                    {
                        lock (lockObj)
                        {
                            // decrement the balance
                            account.Balance = account.Balance - 2;
                        }
                    }
                });
                // start the new task
                decrementTasks[i].Start();
            }
            // wait for all of the tasks to complete
            Task.WaitAll(incrementTasks);
            Task.WaitAll(decrementTasks);
            
            // write out the counter value
            Console.WriteLine("Expected value: -5000");
            Console.WriteLine("Balance: {0}", account.Balance);
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void InterlockedIncrement()
        {
            // create the bank account instance
            BankAccount account = new BankAccount();
            // create an array of tasks
            Task[] tasks = new Task[10];
            for (int i = 0; i < 10; i++)
            {
                // create a new task
                tasks[i] = new Task(() =>
                {
                    // enter a loop for 1000 balance updates
                    for (int j = 0; j < 1000; j++)
                    {
                        // update the balance
                        //account.Balance++;
                        Interlocked.Increment(ref account._balance);
                    }
                });
                // start the new task
                tasks[i].Start();
            }
            // wait for all of the tasks to complete
            Task.WaitAll(tasks);
            // write out the counter value
            Console.WriteLine("Expected value {0}, Balance: {1}",
            10000, account.Balance);
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void BasicUseOfMutexClass()
        {
            // create the bank account instance
            BankAccount account = new BankAccount();
            // create the mutex
            Mutex mutex = new Mutex();
            // create an array of tasks
            Task[] tasks = new Task[10];
            for (int i = 0; i < 10; i++)
            {
                // create a new task
                tasks[i] = new Task(() =>
                {
                    // enter a loop for 1000 balance updates
                    for (int j = 0; j < 1000; j++)
                    {
                        // acquire the mutex
                        bool lockAcquired = mutex.WaitOne();
                        try
                        {
                            // update the balance
                            account.Balance = account.Balance + 1;
                        }
                        finally
                        {
                            // release the mutext
                            if (lockAcquired) mutex.ReleaseMutex();
                        }
                    }
                });
                // start the new task
                tasks[i].Start();
            }
            // wait for all of the tasks to complete
            Task.WaitAll(tasks);
            // write out the counter value
            Console.WriteLine("Expected value {0}, Balance: {1}",
            10000, account.Balance);
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void MultipleLocksWithMutex_WaitAll()
        {
            // create the bank account instances
            BankAccount account1 = new BankAccount();
            BankAccount account2 = new BankAccount();
            // create the mutexes
            Mutex mutex1 = new Mutex();
            Mutex mutex2 = new Mutex();
            // create a new task to update the first account
            Task task1 = new Task(() =>
            {
                // enter a loop for 1000 balance updates
                for (int j = 0; j < 1000; j++)
                {
                    // acquire the lock for the account
                    bool lockAcquired = mutex1.WaitOne(); ;
                    try
                    {
                        // update the balance
                        account1.Balance++;
                    }
                    finally
                    {
                        if (lockAcquired) mutex1.ReleaseMutex();
                    }
                }
            });
            // create a new task to update the first account
            Task task2 = new Task(() =>
            {
                // enter a loop for 1000 balance updates
                for (int j = 0; j < 1000; j++)
                {
                    // acquire the lock for the account
                    bool lockAcquired = mutex2.WaitOne();
                    try
                    {
                        // update the balance
                        account2.Balance += 2;
                    }
                    finally
                    {
                        if (lockAcquired) mutex2.ReleaseMutex();
                    }
                }
            });
            // create a new task to update the first account
            Task task3 = new Task(() =>
            {
                // enter a loop for 1000 balance updates
                for (int j = 0; j < 1000; j++)
                {
                    // acquire the locks for both accounts
                    bool lockAcquired = Mutex.WaitAll(new WaitHandle[] { mutex1, mutex2 });
                    try
                    {
                        // simulate a transfer between accounts
                        account1.Balance++;
                        account2.Balance--;
                    }
                    finally
                    {
                        if (lockAcquired)
                        {
                            mutex1.ReleaseMutex();
                            mutex2.ReleaseMutex();
                        }
                    }
                }
            });
            // start the tasks
            task1.Start();
            task2.Start();
            task3.Start();
            // wait for the tasks to complete
            Task.WaitAll(task1, task2, task3);
            // write out the counter value
            Console.WriteLine("Account1 balance {0}, Account2 balance: {1}",
            account1.Balance, account2.Balance);
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void InterprocessMutex()
        {
            // declare the name we will use for the mutex
            string mutexName = "myOwnMutex";
            // declare the mutext
            Mutex namedMutext;
            try
            {
                // test to see if the named mutex already exists
                namedMutext = Mutex.OpenExisting(mutexName);
            }
            catch (WaitHandleCannotBeOpenedException)
            {
                // the mutext does not exist - we must create it
                namedMutext = new Mutex(false, mutexName);
            }
            // create the task
            Task task = new Task(() =>
            {
                while (true)
                {
                    // acquire the mutex
                    Console.WriteLine("Waiting to acquire Mutex");
                    namedMutext.WaitOne();
                    Console.WriteLine("Acquired Mutex - press enter to release");
                    Console.ReadLine();
                    namedMutext.ReleaseMutex();
                    Console.WriteLine("Released Mutex");
                }
            });
            // start the task
            task.Start();
            // wait for the task to complete
            task.Wait();
        }

        static void DeclarativeSynchronization()
        {
            // create the bank account instance
            BankAccountSyncContext account = new BankAccountSyncContext();
            // create an array of tasks
            Task[] tasks = new Task[10];
            for (int i = 0; i < 10; i++)
            {
                // create a new task
                tasks[i] = new Task(() =>
                {
                    // enter a loop for 1000 balance updates
                    for (int j = 0; j < 1000; j++)
                    {
                        // update the balance
                        account.IncrementBalance();
                    }
                });
                // start the new task
                tasks[i].Start();
            }
            // wait for all of the tasks to complete
            Task.WaitAll(tasks);
            // write out the counter value
            Console.WriteLine("Expected value {0}, Balance: {1}",
            10000, account.GetBalance());
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        //?
        static void ReadWriteLocks()
        {
            // create the reader-writer lock
            ReaderWriterLockSlim rwlock = new ReaderWriterLockSlim();
            // create a cancellation token source
            CancellationTokenSource tokenSource = new CancellationTokenSource();
            // create an array of tasks
            Task[] tasks = new Task[5];
            for (int i = 0; i < 5; i++)
            {
                // create a new task
                tasks[i] = new Task(() =>
                {
                    while (true)
                    {
                        // acqure the read lock
                        rwlock.EnterReadLock();
                        // we now have the lock
                        Console.WriteLine("Read lock acquired - count: {0}",
                        rwlock.CurrentReadCount);
                        // wait - this simulates a read operation
                        tokenSource.Token.WaitHandle.WaitOne(1000);
                        // release the read lock
                        rwlock.ExitReadLock();
                        Console.WriteLine("Read lock released - count {0}",
                        rwlock.CurrentReadCount);
                        // check for cancellation
                        tokenSource.Token.ThrowIfCancellationRequested();
                    }
                }, tokenSource.Token);
                // start the new task
                tasks[i].Start();
            }
            // prompt the user
            Console.WriteLine("Press enter to acquire write lock");
            // wait for the user to press enter
            Console.ReadLine();
            // acquire the write lock
            Console.WriteLine("Requesting write lock");
            rwlock.EnterWriteLock();
            Console.WriteLine("Write lock acquired");
            Console.WriteLine("Press enter to release write lock");
            // wait for the user to press enter
            Console.ReadLine();
            // release the write lock
            rwlock.ExitWriteLock();
            // wait for 2 seconds and then cancel the tasks
            tokenSource.Token.WaitHandle.WaitOne(2000);
            tokenSource.Cancel();
            try
            {
                // wait for the tasks to complete
                Task.WaitAll(tasks);
            }
            catch (AggregateException)
            {
                // do nothing
            }
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }
    }
}
