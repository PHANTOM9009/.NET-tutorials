﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TaskProgramming
{
    class TaskContinuation
    {
        static void Main(string[] args)
        {
            //ReturnResultWithTaskContinuation();
            //MultipleGenerationsOfTaskContinuation();
            //ContinuationsBasedOnExceptions();
            //CancellingContinuations();
            //ChildTask();
            AttachedChildClass();
        }

        static void ReturnResultWithTaskContinuation()
        {

            Task<BankAccount> task = new Task<BankAccount>(() =>
            {
                // create a new bank account
                BankAccount account = new BankAccount();
                // enter a loop
                for (int i = 0; i < 1000; i++)
                {
                    // increment the account total
                    account.Balance++;
                }
                // return the bank account
                return account;
            });
            Task<int> continuationTask
            = task.ContinueWith<int>((Task<BankAccount> antecedent) =>
            {
                Console.WriteLine("Interim Balance: {0}", antecedent.Result.Balance);
                return antecedent.Result.Balance * 2;
            });

            // start the task
            task.Start();
            Console.WriteLine("Final balance: {0}", continuationTask.Result);
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void MultipleGenerationsOfTaskContinuation()
        {
            Task<BankAccount> rootTask = new Task<BankAccount>(() =>
            {
                // create a new bank account
                BankAccount account = new BankAccount();
                // enter a loop
                for (int i = 0; i < 1000; i++)
                {
                    // increment the account total
                    account.Balance++;
                }
                // return the bank account
                return account;
            });
            // create the second-generation task, which will double the antecdent balance
            Task<int> continuationTask1
            = rootTask.ContinueWith<int>((Task<BankAccount> antecedent) =>
            {
                Console.WriteLine("Interim Balance 1: {0}", antecedent.Result.Balance);
                return antecedent.Result.Balance * 2;
            });
            // create a third-generation task, which will print out the result
            Task continuationTask2
            = continuationTask1.ContinueWith((Task<int> antecedent) =>
            {
                Console.WriteLine("Final Balance 1: {0}", antecedent.Result);
            });
            // create a second and third-generation task in one step
            rootTask.ContinueWith<int>((Task<BankAccount> antecedent) =>
            {
                Console.WriteLine("Interim Balance 2: {0}", antecedent.Result.Balance);
                return antecedent.Result.Balance / 2;
            }).ContinueWith((Task<int> antecedent) =>
            {
                Console.WriteLine("Final Balance 2: {0}", antecedent.Result);
            });
            // start the task
            rootTask.Start();
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void ContinuationsBasedOnExceptions()
        {
            // create the first generation task
            Task firstGen = new Task(() =>
            {
                Console.WriteLine("Message from first generation task");
                // comment out this line to stop the fault
                throw new Exception();//Comment this line for executing NotOnFaulted task
            });
            // create the second-generation task - only to run on exception
            Task secondGen1 = firstGen.ContinueWith(antecedent =>
            {
                // write out a message with the antecedent exception
                Console.WriteLine("Antecedent task faulted with type: {0}",
                antecedent.Exception.GetType());
            }, TaskContinuationOptions.OnlyOnFaulted);
            // create the second-generation task - only to run on no exception
            Task secondGen2 = firstGen.ContinueWith(antecedent =>
            {
                Console.WriteLine("Antecedent task NOT faulted");
            }, TaskContinuationOptions.NotOnFaulted);
            // start the first generation task
            firstGen.Start();
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void CancellingContinuations()
        {
            // create a cancellation token source
            CancellationTokenSource tokenSource
            = new CancellationTokenSource();
            // create the antecedent task
            Task task = new Task(() =>
            {
                // write out a message
                Console.WriteLine("Antecedent running");
                // wait indefinately on the token wait handle
                tokenSource.Token.WaitHandle.WaitOne();
                // handle the cancellation exception
                tokenSource.Token.ThrowIfCancellationRequested();
            }, tokenSource.Token);
            // create a selective continuation
            Task neverScheduled = task.ContinueWith(antecedent =>
            {
                // write out a message
                Console.WriteLine("This task will never be scheduled");
            }, tokenSource.Token);
            // create a bad selective contination
            Task badSelective = task.ContinueWith(antecedent =>
            {
                // write out a message
                Console.WriteLine("This task will never be scheduled");
            }, tokenSource.Token, TaskContinuationOptions.OnlyOnCanceled,
            TaskScheduler.Current);
            // create a good selective contiuation
            Task continuation = task.ContinueWith(antecedent =>
            {
                // write out a message
                Console.WriteLine("Continuation running");
            }, TaskContinuationOptions.OnlyOnCanceled);
            // start the task
            task.Start();
            // prompt the user so they can cancel the token
            Console.WriteLine("Press enter to cancel token");
            Console.ReadLine();
            // cancel the token source
            tokenSource.Cancel();
            // wait for the good continuation to complete
            continuation.Wait();
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void ChildTask()
        {
            // create the parent task
            Task parentTask = new Task(() =>
            {
                // create the first child task
                Task childTask = new Task(() =>
                {
                    // write out a message and wait
                    Console.WriteLine("Child task running");
                    Thread.Sleep(1000);
                    Console.WriteLine("Child task finished");
                    throw new Exception();
                });
                Console.WriteLine("Starting child task...");
                childTask.Start();
            });
            // start the parent task
            parentTask.Start();
            // wait for the parent task
            Console.WriteLine("Waiting for parent task");
            parentTask.Wait();
            Console.WriteLine("Parent task finished");
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }

        static void AttachedChildClass()
        {
            // create the parent task
            Task parentTask = new Task(() =>
            {
                // create the first child task
                Task childTask = new Task(() =>
                {
                    // write out a message and wait
                    Console.WriteLine("Child 1 running");
                    Thread.Sleep(1000);
                    Console.WriteLine("Child 1 finished");
                    throw new Exception();
                }, TaskCreationOptions.AttachedToParent);
                // create an attached continuation
                childTask.ContinueWith(antecedent =>
                {
                    // write out a message and wait
                    Console.WriteLine("Continuation running");
                    Thread.Sleep(1000);
                    Console.WriteLine("Continuation finished");
                },
                TaskContinuationOptions.AttachedToParent
                | TaskContinuationOptions.OnlyOnFaulted);
                Console.WriteLine("Starting child task...");
                childTask.Start();
            });
            // start the parent task
            parentTask.Start();
            try
            {
                // wait for the parent task
                Console.WriteLine("Waiting for parent task");
                parentTask.Wait();
                Console.WriteLine("Parent task finished");
            }
            catch (AggregateException ex)
            {
                Console.WriteLine("Exception: {0}", ex.InnerException.GetType());
            }
            // wait for input before exiting
            Console.WriteLine("Press enter to finish");
            Console.ReadLine();
        }
    }
}
